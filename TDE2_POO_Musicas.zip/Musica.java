import java.io.Serializable;

public class Musica implements Serializable, Comparable<Musica> {
    private String titulo;
    private String artista;
    private int duracao;

    public Musica(String titulo, String artista, int duracao) {
        this.titulo = titulo;
        this.artista = artista;
        this.duracao = duracao;
    }

    public String getTitulo() { return titulo; }
    public String getArtista() { return artista; }
    public int getDuracao() { return duracao; }

    @Override
    public int compareTo(Musica outra) {
        return this.titulo.compareToIgnoreCase(outra.titulo);
    }

    @Override
    public String toString() {
        return String.format("%s - %s (%ds)", titulo, artista, duracao);
    }
}