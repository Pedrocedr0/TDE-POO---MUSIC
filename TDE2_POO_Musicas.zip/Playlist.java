import java.io.Serializable;
import java.util.*;

public class Playlist implements Serializable {
    private String nome;
    private List<Musica> musicas;

    public Playlist(String nome) {
        this.nome = nome;
        this.musicas = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }

    public List<Musica> getMusicas() {
        return musicas;
    }

    public void adicionarMusica(Musica m) {
        musicas.add(m);
    }

    public void ordenarPorTitulo() {
        Collections.sort(musicas);
    }

    public void ordenarPorArtista() {
        musicas.sort(Comparadores.porArtista());
    }

    public void ordenarPorDuracao() {
        musicas.sort(Comparadores.porDuracao());
    }

    @Override
    public String toString() {
        return "Playlist: " + nome + "\n" + String.join("\n", musicas.stream().map(Object::toString).toList());
    }
}