import java.util.Comparator;

public class Comparadores {
    public static Comparator<Musica> porArtista() {
        return Comparator.comparing(Musica::getArtista, String.CASE_INSENSITIVE_ORDER);
    }

    public static Comparator<Musica> porDuracao() {
        return Comparator.comparingInt(Musica::getDuracao);
    }
}