import java.util.*;

public class Main {
    private static List<Playlist> playlists;

    public static void main(String[] args) {
        playlists = Persistencia.carregarPlaylists();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n🎵 Sistema de Gerenciamento de Músicas 🎵");
            System.out.println("1. Criar nova playlist");
            System.out.println("2. Listar playlists salvas");
            System.out.println("3. Adicionar música a uma playlist");
            System.out.println("4. Ordenar músicas de uma playlist");
            System.out.println("5. Salvar playlists");
            System.out.println("0. Sair");
            System.out.print("Escolha: ");

            int opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1 -> criarPlaylist(scanner);
                case 2 -> listarPlaylists();
                case 3 -> adicionarMusica(scanner);
                case 4 -> ordenarMusicas(scanner);
                case 5 -> {
                    Persistencia.salvarPlaylists(playlists);
                    System.out.println("Playlists salvas com sucesso.");
                }
                case 0 -> {
                    Persistencia.salvarPlaylists(playlists);
                    System.exit(0);
                }
                default -> System.out.println("Opção inválida.");
            }
        }
    }

    private static void criarPlaylist(Scanner scanner) {
        System.out.print("Nome da nova playlist: ");
        String nome = scanner.nextLine();
        playlists.add(new Playlist(nome));
        System.out.println("Playlist criada!");
    }

    private static void listarPlaylists() {
        if (playlists.isEmpty()) {
            System.out.println("Nenhuma playlist encontrada.");
            return;
        }
        for (int i = 0; i < playlists.size(); i++) {
            System.out.printf("%d. %s\n", i, playlists.get(i).getNome());
        }
    }

    private static void adicionarMusica(Scanner scanner) {
        listarPlaylists();
        System.out.print("Selecione a playlist: ");
        int idx = scanner.nextInt();
        scanner.nextLine();
        if (idx < 0 || idx >= playlists.size()) {
            System.out.println("Índice inválido.");
            return;
        }

        System.out.print("Título: ");
        String titulo = scanner.nextLine();
        System.out.print("Artista: ");
        String artista = scanner.nextLine();
        System.out.print("Duração (segundos): ");
        int duracao = scanner.nextInt();

        playlists.get(idx).adicionarMusica(new Musica(titulo, artista, duracao));
        System.out.println("Música adicionada!");
    }

    private static void ordenarMusicas(Scanner scanner) {
        listarPlaylists();
        System.out.print("Selecione a playlist: ");
        int idx = scanner.nextInt();
        scanner.nextLine();
        if (idx < 0 || idx >= playlists.size()) {
            System.out.println("Índice inválido.");
            return;
        }

        System.out.println("1. Título\n2. Artista\n3. Duração");
        int ordem = scanner.nextInt();

        switch (ordem) {
            case 1 -> playlists.get(idx).ordenarPorTitulo();
            case 2 -> playlists.get(idx).ordenarPorArtista();
            case 3 -> playlists.get(idx).ordenarPorDuracao();
            default -> System.out.println("Critério inválido.");
        }

        System.out.println("Playlist ordenada:");
        System.out.println(playlists.get(idx));
    }
}