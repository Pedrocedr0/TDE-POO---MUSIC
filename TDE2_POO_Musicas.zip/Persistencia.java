import java.io.*;
import java.util.*;

public class Persistencia {
    private static final String ARQUIVO = "playlists.dat";

    public static void salvarPlaylists(List<Playlist> playlists) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(ARQUIVO))) {
            out.writeObject(playlists);
        } catch (IOException e) {
            System.err.println("Erro ao salvar playlists: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    public static List<Playlist> carregarPlaylists() {
        File file = new File(ARQUIVO);
        if (!file.exists()) return new ArrayList<>();

        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
            return (List<Playlist>) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Erro ao carregar playlists: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}